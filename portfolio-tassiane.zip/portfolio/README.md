# Portfólio – Mapas e Análises

Aqui estão algumas imagens de projetos realizados com ArcGIS Pro.

### 🗺️ Mapa 1 – Uso da Terra
Descrição: Mapa elaborado com ferramentas de Clip e Simbologia no ArcGIS Pro, representando o uso da terra em área agrícola.

### 🧭 Mapa 2 – Análise Espacial
Descrição: Mapa para análise de produtividade com base em NDVI e imagens de satélite.

(As imagens estão listadas abaixo nesta pasta.)
