# Sobre Mim

Sou Tassiane Viana Barbosa, formada em Engenharia Agronômica com especialização em Solos, Nutrição e Plantas. 
Tenho interesse especial em geoprocessamento aplicado ao agronegócio, com experiência em mapeamento do uso da terra, análise espacial e elaboração de mapas temáticos.

