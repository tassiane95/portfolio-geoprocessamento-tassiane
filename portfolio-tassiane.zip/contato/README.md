# Contato

- E-mail: tassiane.barbosa10@gmail.com  
- Telefone: (11) 99996-8245  
- LinkedIn: [linkedin.com/in/seu-usuario-linkedin](https://www.linkedin.com/in/seu-usuario-linkedin)
